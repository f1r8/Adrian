import java.util.List;
import java.util.stream.Stream;

public class Hotpot {
    private List<Ingredient> ingredients;

    public Hotpot(List<Ingredient> ingredients) {
        this.ingredients = ingredients;
    }

    public String chop(long n) {
        return "";
    }

    public List<Ingredient> cook() {
        return null;
    }
    public long mostOrderedAmount() {
        return 0L;
    }

    public List<Ingredient> takeUnique() {
        return null;
    }

    public String combine(Hotpot other) { 
        return "";
    }

    public String mostOrdered() {
        return "";
    }
}
